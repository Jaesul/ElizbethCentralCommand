#include "PSM.h"
#if defined(ESP32)
#include "driver/gpio.h"
#include "esp_timer.h"
#endif

PSM* _thePSM;

static inline void psmPrintBannerOnce() {
  static bool printed = false;
  if (printed) return;
  printed = true;
  // Best effort: only prints if Serial has been started by the sketch.
  if (Serial) {
    Serial.print("[PSM] ");
    Serial.println(PSM_LIBRARY_VERSION);
  }
}

PSM::PSM(unsigned char sensePin, unsigned char controlPin, unsigned int range, int mode, unsigned char divider, unsigned char interruptMinTimeDiff) {
  _thePSM = this;

  pinMode(sensePin, INPUT_PULLUP);
  PSM::_sensePin = sensePin;

  pinMode(controlPin, OUTPUT);
  PSM::_controlPin = controlPin;

  PSM::_mode = mode;
  PSM::_divider = divider > 0 ? divider : 1;

#if defined(ESP32)
  // On ESP32 Arduino core, attaching interrupts from global constructors can be flaky
  // (core not fully initialized yet). Defer attachment until first use (initTimer/cps).
  PSM::_interruptAttached = false;
#else
  uint32_t interruptNum = digitalPinToInterrupt(PSM::_sensePin);

  if (interruptNum != NOT_AN_INTERRUPT) {
    attachInterrupt(interruptNum, onZCInterrupt, mode);
  }
  PSM::_interruptAttached = (interruptNum != NOT_AN_INTERRUPT);
#endif

  PSM::_range = range;
  PSM::_interruptMinTimeDiff = interruptMinTimeDiff;
}

void PSM::ensureInterruptAttached() {
  if (_interruptAttached) return;
  uint32_t interruptNum = digitalPinToInterrupt(PSM::_sensePin);
  if (interruptNum == NOT_AN_INTERRUPT) return;
#if defined(ESP32)
  attachInterrupt(PSM::_sensePin, onZCInterrupt, _mode);
#else
  attachInterrupt(interruptNum, onZCInterrupt, _mode);
#endif
  _interruptAttached = true;
}

void onPSMInterrupt() __attribute__((weak));
void onPSMInterrupt() {}

void PSM::onZCInterrupt(void) {
#if defined(ESP32)
  // ISR-safe timestamp
  const uint32_t nowUs = (uint32_t)esp_timer_get_time();
  const unsigned long nowMs = (unsigned long)(nowUs / 1000u);
  if (_thePSM->_interruptMinTimeDiff > 0) {
    const unsigned long lastMs = _thePSM->_lastMillis;
    if ((nowMs - lastMs) < (unsigned long)_thePSM->_interruptMinTimeDiff) {
      return;
    }
  }
  _thePSM->_lastMillis = nowMs;
#else
  if (_thePSM->_interruptMinTimeDiff > 0 && millis() - _thePSM->_interruptMinTimeDiff < _thePSM->_lastMillis) {
    if (millis() >= _thePSM->_lastMillis) {
      return;
    }
  }

  _thePSM->_lastMillis = millis();
#endif

  onPSMInterrupt();

  _thePSM->calculateSkipFromZC();

  if (_thePSM->_psmIntervalTimerInitialized) {
#if defined(ESP32)
    // Restart one-shot timer to END the gate pulse after _psmIntervalUs.
    timerWrite(_thePSM->_psmIntervalTimer, 0);
    timerAlarm(_thePSM->_psmIntervalTimer, _thePSM->_psmIntervalUs, false, 0);
    timerStart(_thePSM->_psmIntervalTimer);
#else
    _thePSM->_psmIntervalTimer->setCount(0);
    _thePSM->_psmIntervalTimer->resume();
#endif
  }
}

void PSM::onPSMTimerInterrupt(void) {
#if defined(ESP32)
  timerStop(_thePSM->_psmIntervalTimer);
#else
  _thePSM->_psmIntervalTimer->pause();
#endif
  _thePSM->updateControl(true);
}

void PSM::set(unsigned int value) {
  if (value < PSM::_range) {
    PSM::_value = value;
  }
  else {
    PSM::_value = PSM::_range;
  }
}

long PSM::getCounter(void) {
  return PSM::_counter;
}

void PSM::resetCounter(void) {
  PSM::_counter = 0;
}

void PSM::stopAfter(long counter) {
  PSM::_stopAfter = counter;
}

void PSM::calculateSkipFromZC(void) {
  if (_thePSM->_dividerCounter >= _thePSM->_divider - 1) {
    _thePSM->_dividerCounter -= _thePSM->_divider - 1;
    _thePSM->calculateSkip();
  }
  else {
    _thePSM->_dividerCounter++;
  }
  _thePSM->updateControl(false);
}

void PSM::calculateSkip(void) {
  PSM::_a += PSM::_value;

  if (PSM::_a >= PSM::_range) {
    PSM::_a -= PSM::_range;
    PSM::_skip = false;
  }
  else {
    PSM::_skip = true;
  }

  if (PSM::_a > PSM::_range) {
    PSM::_a = 0;
    PSM::_skip = false;
  }

  if (!PSM::_skip) {
    PSM::_counter++;
  }

  if (!PSM::_skip
    && PSM::_stopAfter > 0
    && PSM::_counter > PSM::_stopAfter) {
    PSM::_skip = true;
  }
}

void PSM::updateControl(bool forceDisable) {
#if defined(ESP32)
  gpio_set_level((gpio_num_t)PSM::_controlPin, (forceDisable || PSM::_skip) ? 0 : 1);
#else
  if (forceDisable || PSM::_skip) {
    digitalWrite(PSM::_controlPin, LOW);
  }
  else {
    digitalWrite(PSM::_controlPin, HIGH);
  }
#endif
}

unsigned int PSM::cps(void) {
  ensureInterruptAttached();
  unsigned int range = PSM::_range;
  unsigned int value = PSM::_value;
  unsigned char divider = PSM::_divider;

  PSM::_range = 0xFFFF;
  PSM::_value = 1;
  PSM::_a = 0;
  PSM::_divider = 1;
  PSM::_skip = true;

  unsigned long stopAt = millis() + 1000;

  while (millis() < stopAt) {
    delay(0);
  }

  unsigned int result = PSM::_a;

  PSM::_range = range;
  PSM::_value = value;
  PSM::_a = 0;
  PSM::_divider = divider;

  return result;
}

unsigned long PSM::getLastMillis(void) {
  return PSM::_lastMillis;
}

unsigned char PSM::getDivider(void) {
  return PSM::_divider;
}

void PSM::setDivider(unsigned char divider) {
  PSM::_divider = divider > 0 ? divider : 1;
}

void PSM::shiftDividerCounter(char value) {
  PSM::_dividerCounter += value;
}

#if !defined(ESP32)
void PSM::initTimer(uint16_t delay, TIM_TypeDef* timerInstance) {
  uint32_t us = delay > 1000u ? delay : delay > 55u ? 5500u : 6600u;

  PSM::_psmIntervalTimer = new HardwareTimer(timerInstance);
  PSM::_psmIntervalTimer->setOverflow(us, MICROSEC_FORMAT);
  PSM::_psmIntervalTimer->setInterruptPriority(0, 0);
  PSM::_psmIntervalTimer->attachInterrupt(onPSMTimerInterrupt);

  PSM::_psmIntervalTimerInitialized = true;
  psmPrintBannerOnce();
}
#endif

#if defined(ESP32)
void PSM::initTimer(uint16_t delay) {
  ensureInterruptAttached();
  // Keep the same semantics as STM32: `delay` is not a literal pulse width in this library;
  // it maps to a recommended gate pulse width for 50/60Hz TRIAC behavior.
  uint32_t us = delay > 1000u ? delay : delay > 55u ? 5500u : 6600u;

  _psmIntervalUs = us;

  if (_psmIntervalTimer == nullptr) {
    // Use the same API style as existing ESP32 sketches in this repo (timerBegin(frequency)).
    _psmIntervalTimer = timerBegin(1000000); // 1MHz -> 1us ticks
    timerAttachInterrupt(_psmIntervalTimer, &onPSMTimerInterrupt);
    timerStop(_psmIntervalTimer);
  }

  _psmIntervalTimerInitialized = true;
  psmPrintBannerOnce();
}
#endif
