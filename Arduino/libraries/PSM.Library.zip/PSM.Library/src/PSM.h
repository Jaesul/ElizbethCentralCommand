#ifndef PSM_h
#define PSM_h

#include "Arduino.h"

// Version marker for sanity-checking which library build is running.
// (Not an upstream version; this is a local tag for the ESP32 port work.)
#ifndef PSM_LIBRARY_VERSION
#define PSM_LIBRARY_VERSION "feature/timer+esp32-port.1"
#endif

class PSM
{
public:
  PSM(unsigned char sensePin, unsigned char controlPin, unsigned int range, int mode = RISING, unsigned char divider = 1, unsigned char interruptMinTimeDiff = 0);

  // Configure the internal timer used to END the TRIAC control pulse.
  //
  // On STM32 (Arduino STM32 core), this uses HardwareTimer + TIM_TypeDef*.
  // On ESP32 (Arduino-ESP32), this uses hw_timer_t.
#if defined(ESP32)
  void initTimer(uint16_t delay);
#else
  void initTimer(uint16_t delay, TIM_TypeDef* timerInstance = TIM1);
#endif

  void set(unsigned int value);

  long getCounter(void);
  void resetCounter(void);

  void stopAfter(long counter);

  unsigned int cps(void);
  unsigned long getLastMillis(void);

  unsigned char getDivider(void);
  void setDivider(unsigned char divider = 1);
  void shiftDividerCounter(char value = 1);

private:
  void ensureInterruptAttached();

  // ISRs: keep them in IRAM on ESP32.
#if defined(ESP32)
  static void IRAM_ATTR onZCInterrupt(void);
#else
  static inline void onZCInterrupt(void);
#endif
  static inline void calculateSkipFromZC(void);
#if defined(ESP32)
  static void IRAM_ATTR onPSMTimerInterrupt(void);
#else
  static inline void onPSMTimerInterrupt(void);
#endif
  void calculateSkip(void);
  void updateControl(bool forceDisable = true);

  unsigned char _sensePin;
  unsigned char _controlPin;
  unsigned int _range;
  int _mode;
  bool _interruptAttached = false;
  unsigned char _divider = 1;
  unsigned char _dividerCounter = 1;
  unsigned char _interruptMinTimeDiff;
  volatile unsigned int _value;
  volatile unsigned int _a;
  volatile bool _skip = true;
  volatile long _counter;
  volatile long _stopAfter;
  volatile unsigned long _lastMillis = 0;

  bool _psmIntervalTimerInitialized = false;
#if defined(ESP32)
  hw_timer_t* _psmIntervalTimer = nullptr;
  uint32_t _psmIntervalUs = 0;
#else
  HardwareTimer* _psmIntervalTimer;
#endif
};

extern PSM* _thePSM;

#endif
